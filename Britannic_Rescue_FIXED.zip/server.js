
const express = require("express");
const http = require("http");
const { WebSocketServer } = require("ws");

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });
app.use(express.static("public"));

const rooms = new Map();

function code() {
  const chars="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let c="";
  do { c=""; for(let i=0;i<5;i++) c+=chars[Math.floor(Math.random()*chars.length)]; }
  while(rooms.has(c));
  return c;
}
function send(ws,x){ if(ws.readyState===1) ws.send(JSON.stringify(x)); }
function broadcast(room,x){ room.players.forEach(p=>send(p.ws,x)); }
function state(room){
  return {type:"state", water:room.water,hull:room.hull,morale:room.morale,
    fires:room.fires,lifeboats:room.lifeboats,started:room.started,ended:room.ended,
    saved:room.saved,players:room.players.map(p=>({name:p.name,role:p.role})),
    log:room.log.slice(-12)};
}
function log(room,x){room.log.push(x);}

wss.on("connection",(ws)=>{
  ws.on("message",(raw)=>{
    let m; try{m=JSON.parse(raw)}catch{return}

    if(m.type==="create"){
      const c=code();
      const p={ws,name:String(m.name||"Captain").slice(0,18),role:"Captain"};
      const r={players:[p],water:12,hull:100,morale:70,fires:1,lifeboats:8,
        started:false,ended:false,saved:false,log:["🚢 Room created. Share the code with your crew."]};
      rooms.set(c,r); ws.room=c; ws.player=p;
      send(ws,{type:"created",code:c});
      send(ws,state(r));
      return;
    }

    if(m.type==="join"){
      const c=String(m.code||"").trim().toUpperCase();
      const r=rooms.get(c);
      if(!r){send(ws,{type:"error",message:"Room not found. Check the code."});return}
      if(r.ended){send(ws,{type:"error",message:"That rescue has already ended."});return}
      if(r.players.length>=10){send(ws,{type:"error",message:"Room is full."});return}
      const p={ws,name:String(m.name||"Crew Member").slice(0,18),
        role:r.players.length===1?"Officer":"Crew"};
      r.players.push(p);ws.room=c;ws.player=p;
      log(r,`👋 ${p.name} joined the crew.`);
      broadcast(r,state(r)); return;
    }

    const r=rooms.get(ws.room); if(!r)return;

    if(m.type==="start"){
      if(ws.player.role!=="Captain")return;
      r.water=12;r.hull=100;r.morale=70;r.fires=1;r.lifeboats=8;
      r.started=true;r.ended=false;r.saved=false;
      r.log=["🚨 ALL HANDS ON DECK!","The rescue has begun!"];
      broadcast(r,state(r));return;
    }

    if(m.type==="action" && r.started && !r.ended){
      let t="";
      if(m.action==="pump"){r.water=Math.max(0,r.water-7);t=`🛠️ ${ws.player.name} works the pumps!`;}
      if(m.action==="repair"){r.hull=Math.min(100,r.hull+8);t=`🔧 ${ws.player.name} repairs the hull!`;}
      if(m.action==="fire"){r.fires=Math.max(0,r.fires-1);r.morale=Math.min(100,r.morale+3);t=`🔥 ${ws.player.name} fights a fire!`;}
      if(m.action==="lifeboat"){
        if(r.lifeboats>0){r.lifeboats--;t=`🛟 ${ws.player.name} prepares a lifeboat.`}
        else t="🛟 There are no lifeboats left.";
      }
      if(m.action==="command"){
        const cmd=String(m.command||"").slice(0,100);
        if(cmd.toLowerCase().includes("all hands")){
          r.water=Math.max(0,r.water-10);r.morale=Math.min(100,r.morale+8);
          t=`📢 ${ws.player.name}: ${cmd} — everyone rushes to their stations!`;
        } else { r.morale=Math.min(100,r.morale+2); t=`📢 ${ws.player.name}: ${cmd}`; }
      }
      if(t)log(r,t);

      // Every action advances the emergency.
      r.water += Math.max(1,3-Math.floor((100-r.hull)/30));
      if(r.fires>0)r.hull-=1;

      if(r.water>=100 || r.hull<=0){r.ended=true;r.saved=false;log(r,"💥 THE SHIP IS LOST.");}
      if(r.water<=0 && r.hull>=80 && r.fires===0){r.ended=true;r.saved=true;log(r,"🎉 THE BRITANNIC IS SAVED!");}
      broadcast(r,state(r));
    }
  });

  ws.on("close",()=>{
    const r=rooms.get(ws.room);if(!r)return;
    r.players=r.players.filter(p=>p.ws!==ws);
    if(r.players.length)broadcast(r,state(r));else rooms.delete(ws.room);
  });
});

const PORT=process.env.PORT||3000;
server.listen(PORT,()=>console.log("Britannic Rescue running on "+PORT));
