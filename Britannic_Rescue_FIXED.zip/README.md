# Britannic Rescue — fixed

This is a browser multiplayer game. The important part: the game needs its Node/WebSocket server running somewhere. A plain HTML file cannot create a shared multiplayer room by itself.

## Local computer
Install Node.js, then in this folder:
npm install
npm start

Open http://localhost:3000

## Chromebook + friends over the internet
The easiest setup is to deploy this folder to a Node-compatible web host that gives you an HTTPS URL. Open that URL in Chrome on the Chromebook and share it with friends. Because the page automatically uses `wss://` when served over HTTPS, the WebSocket connection works in Chrome.

The site must allow WebSocket connections. Do not use a static-only host such as GitHub Pages for the multiplayer server.

## Same Wi-Fi
Run the server on one computer, find that computer's local IP, and have the Chromebook open:
http://LOCAL-IP:3000

## Controls
Create a room, share the 5-character code, and press START. Crew members can pump, repair, fight fires, prepare lifeboats, and type commands. "ALL HANDS ON DECK!" gives the crew a special emergency boost.

No game can guarantee that a school/work network will not block a site; use it only on networks where playing is permitted.
